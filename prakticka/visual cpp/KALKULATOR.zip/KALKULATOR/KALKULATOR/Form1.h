#pragma once

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ pdisp;
	protected:

	private: System::Windows::Forms::TextBox^ disp;
	protected:

	private: System::Windows::Forms::TableLayoutPanel^ tableLayoutPanel1;
	private: System::Windows::Forms::Button^ pi;

	private: System::Windows::Forms::Button^ eq;
	private: System::Windows::Forms::Button^ num0;
	private: System::Windows::Forms::Button^ comma;
	private: System::Windows::Forms::Button^ opposite;




	private: System::Windows::Forms::Button^ num3;
	private: System::Windows::Forms::Button^ num2;
	private: System::Windows::Forms::Button^ num1;
	private: System::Windows::Forms::Button^ naDruhou;

	private: System::Windows::Forms::Button^ num6;

	private: System::Windows::Forms::Button^ num5;

	private: System::Windows::Forms::Button^ num4;
	private: System::Windows::Forms::Button^ pow;


	private: System::Windows::Forms::Button^ num9;

	private: System::Windows::Forms::Button^ num8;

	private: System::Windows::Forms::Button^ num7;
	private: System::Windows::Forms::Button^ sqrt;


	private: System::Windows::Forms::Button^ del;
	private: System::Windows::Forms::Button^ Ce;
	private: System::Windows::Forms::Button^ root;



	private: System::Windows::Forms::Button^ plus;
	private: System::Windows::Forms::Button^ minus;
	private: System::Windows::Forms::Button^ krat;
	private: System::Windows::Forms::Button^ deleno;




	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ ln;

	private: System::Windows::Forms::Button^ random;

	private: System::Windows::Forms::Button^ abs;

	private: System::Windows::Forms::Button^ faktorial;

	private: System::Windows::Forms::Button^ prev;
	private: System::Windows::Forms::Button^ deg;

	private: System::Windows::Forms::Button^ cos;
	private: System::Windows::Forms::Button^ sin;
	private: System::Windows::Forms::Button^ tg;
	private: System::Windows::Forms::Button^ cotg;
	private: System::Windows::Forms::Label^ lbldeg;
	private: System::Windows::Forms::Button^ MS;
	private: System::Windows::Forms::Button^ Mminus;
	private: System::Windows::Forms::Button^ Mplus;
	private: System::Windows::Forms::Button^ MR;
	private: System::Windows::Forms::Button^ MC;
	private: System::Windows::Forms::Label^ memory;
	private: System::Windows::Forms::Label^ lblmemory;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->pdisp = (gcnew System::Windows::Forms::TextBox());
			this->disp = (gcnew System::Windows::Forms::TextBox());
			this->tableLayoutPanel1 = (gcnew System::Windows::Forms::TableLayoutPanel());
			this->MS = (gcnew System::Windows::Forms::Button());
			this->Mminus = (gcnew System::Windows::Forms::Button());
			this->Mplus = (gcnew System::Windows::Forms::Button());
			this->MR = (gcnew System::Windows::Forms::Button());
			this->MC = (gcnew System::Windows::Forms::Button());
			this->deg = (gcnew System::Windows::Forms::Button());
			this->cos = (gcnew System::Windows::Forms::Button());
			this->sin = (gcnew System::Windows::Forms::Button());
			this->tg = (gcnew System::Windows::Forms::Button());
			this->cotg = (gcnew System::Windows::Forms::Button());
			this->ln = (gcnew System::Windows::Forms::Button());
			this->random = (gcnew System::Windows::Forms::Button());
			this->abs = (gcnew System::Windows::Forms::Button());
			this->faktorial = (gcnew System::Windows::Forms::Button());
			this->prev = (gcnew System::Windows::Forms::Button());
			this->plus = (gcnew System::Windows::Forms::Button());
			this->minus = (gcnew System::Windows::Forms::Button());
			this->krat = (gcnew System::Windows::Forms::Button());
			this->deleno = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->eq = (gcnew System::Windows::Forms::Button());
			this->num0 = (gcnew System::Windows::Forms::Button());
			this->comma = (gcnew System::Windows::Forms::Button());
			this->opposite = (gcnew System::Windows::Forms::Button());
			this->num3 = (gcnew System::Windows::Forms::Button());
			this->num2 = (gcnew System::Windows::Forms::Button());
			this->num1 = (gcnew System::Windows::Forms::Button());
			this->naDruhou = (gcnew System::Windows::Forms::Button());
			this->num6 = (gcnew System::Windows::Forms::Button());
			this->num5 = (gcnew System::Windows::Forms::Button());
			this->num4 = (gcnew System::Windows::Forms::Button());
			this->pow = (gcnew System::Windows::Forms::Button());
			this->num9 = (gcnew System::Windows::Forms::Button());
			this->num8 = (gcnew System::Windows::Forms::Button());
			this->num7 = (gcnew System::Windows::Forms::Button());
			this->sqrt = (gcnew System::Windows::Forms::Button());
			this->del = (gcnew System::Windows::Forms::Button());
			this->Ce = (gcnew System::Windows::Forms::Button());
			this->root = (gcnew System::Windows::Forms::Button());
			this->pi = (gcnew System::Windows::Forms::Button());
			this->lbldeg = (gcnew System::Windows::Forms::Label());
			this->memory = (gcnew System::Windows::Forms::Label());
			this->lblmemory = (gcnew System::Windows::Forms::Label());
			this->tableLayoutPanel1->SuspendLayout();
			this->SuspendLayout();
			// 
			// pdisp
			// 
			this->pdisp->BackColor = System::Drawing::Color::SkyBlue;
			this->pdisp->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->pdisp->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->pdisp->Location = System::Drawing::Point(12, 12);
			this->pdisp->Name = L"pdisp";
			this->pdisp->Size = System::Drawing::Size(721, 24);
			this->pdisp->TabIndex = 0;
			this->pdisp->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// disp
			// 
			this->disp->BackColor = System::Drawing::Color::SkyBlue;
			this->disp->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->disp->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 27.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->disp->Location = System::Drawing::Point(12, 42);
			this->disp->Name = L"disp";
			this->disp->Size = System::Drawing::Size(721, 42);
			this->disp->TabIndex = 1;
			this->disp->Text = L"0";
			this->disp->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// tableLayoutPanel1
			// 
			this->tableLayoutPanel1->ColumnCount = 8;
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->ColumnStyles->Add((gcnew System::Windows::Forms::ColumnStyle(System::Windows::Forms::SizeType::Percent,
				12.5F)));
			this->tableLayoutPanel1->Controls->Add(this->MS, 7, 4);
			this->tableLayoutPanel1->Controls->Add(this->Mminus, 7, 3);
			this->tableLayoutPanel1->Controls->Add(this->Mplus, 7, 2);
			this->tableLayoutPanel1->Controls->Add(this->MR, 7, 1);
			this->tableLayoutPanel1->Controls->Add(this->MC, 7, 0);
			this->tableLayoutPanel1->Controls->Add(this->deg, 6, 4);
			this->tableLayoutPanel1->Controls->Add(this->cos, 6, 3);
			this->tableLayoutPanel1->Controls->Add(this->sin, 6, 2);
			this->tableLayoutPanel1->Controls->Add(this->tg, 6, 1);
			this->tableLayoutPanel1->Controls->Add(this->cotg, 6, 0);
			this->tableLayoutPanel1->Controls->Add(this->ln, 5, 4);
			this->tableLayoutPanel1->Controls->Add(this->random, 5, 3);
			this->tableLayoutPanel1->Controls->Add(this->abs, 5, 2);
			this->tableLayoutPanel1->Controls->Add(this->faktorial, 5, 1);
			this->tableLayoutPanel1->Controls->Add(this->prev, 5, 0);
			this->tableLayoutPanel1->Controls->Add(this->plus, 4, 4);
			this->tableLayoutPanel1->Controls->Add(this->minus, 4, 3);
			this->tableLayoutPanel1->Controls->Add(this->krat, 4, 2);
			this->tableLayoutPanel1->Controls->Add(this->deleno, 4, 1);
			this->tableLayoutPanel1->Controls->Add(this->button6, 4, 0);
			this->tableLayoutPanel1->Controls->Add(this->eq, 3, 4);
			this->tableLayoutPanel1->Controls->Add(this->num0, 2, 4);
			this->tableLayoutPanel1->Controls->Add(this->comma, 1, 4);
			this->tableLayoutPanel1->Controls->Add(this->opposite, 0, 4);
			this->tableLayoutPanel1->Controls->Add(this->num3, 3, 3);
			this->tableLayoutPanel1->Controls->Add(this->num2, 2, 3);
			this->tableLayoutPanel1->Controls->Add(this->num1, 1, 3);
			this->tableLayoutPanel1->Controls->Add(this->naDruhou, 0, 3);
			this->tableLayoutPanel1->Controls->Add(this->num6, 3, 2);
			this->tableLayoutPanel1->Controls->Add(this->num5, 2, 2);
			this->tableLayoutPanel1->Controls->Add(this->num4, 1, 2);
			this->tableLayoutPanel1->Controls->Add(this->pow, 0, 2);
			this->tableLayoutPanel1->Controls->Add(this->num9, 3, 1);
			this->tableLayoutPanel1->Controls->Add(this->num8, 2, 1);
			this->tableLayoutPanel1->Controls->Add(this->num7, 1, 1);
			this->tableLayoutPanel1->Controls->Add(this->sqrt, 0, 1);
			this->tableLayoutPanel1->Controls->Add(this->del, 3, 0);
			this->tableLayoutPanel1->Controls->Add(this->Ce, 2, 0);
			this->tableLayoutPanel1->Controls->Add(this->root, 1, 0);
			this->tableLayoutPanel1->Controls->Add(this->pi, 0, 0);
			this->tableLayoutPanel1->Location = System::Drawing::Point(12, 114);
			this->tableLayoutPanel1->Name = L"tableLayoutPanel1";
			this->tableLayoutPanel1->RowCount = 5;
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 20)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 20)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 20)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 20)));
			this->tableLayoutPanel1->RowStyles->Add((gcnew System::Windows::Forms::RowStyle(System::Windows::Forms::SizeType::Percent, 20)));
			this->tableLayoutPanel1->Size = System::Drawing::Size(721, 508);
			this->tableLayoutPanel1->TabIndex = 2;
			// 
			// MS
			// 
			this->MS->Dock = System::Windows::Forms::DockStyle::Fill;
			this->MS->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->MS->Location = System::Drawing::Point(633, 407);
			this->MS->Name = L"MS";
			this->MS->Size = System::Drawing::Size(85, 98);
			this->MS->TabIndex = 39;
			this->MS->Text = L"MS";
			this->MS->UseVisualStyleBackColor = true;
			this->MS->Click += gcnew System::EventHandler(this, &Form1::MS_Click);
			// 
			// Mminus
			// 
			this->Mminus->Dock = System::Windows::Forms::DockStyle::Fill;
			this->Mminus->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->Mminus->Location = System::Drawing::Point(633, 306);
			this->Mminus->Name = L"Mminus";
			this->Mminus->Size = System::Drawing::Size(85, 95);
			this->Mminus->TabIndex = 38;
			this->Mminus->Text = L"M-";
			this->Mminus->UseVisualStyleBackColor = true;
			this->Mminus->Click += gcnew System::EventHandler(this, &Form1::Mminus_Click);
			// 
			// Mplus
			// 
			this->Mplus->Dock = System::Windows::Forms::DockStyle::Fill;
			this->Mplus->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->Mplus->Location = System::Drawing::Point(633, 205);
			this->Mplus->Name = L"Mplus";
			this->Mplus->Size = System::Drawing::Size(85, 95);
			this->Mplus->TabIndex = 37;
			this->Mplus->Text = L"M+";
			this->Mplus->UseVisualStyleBackColor = true;
			this->Mplus->Click += gcnew System::EventHandler(this, &Form1::Mplus_Click);
			// 
			// MR
			// 
			this->MR->Dock = System::Windows::Forms::DockStyle::Fill;
			this->MR->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->MR->Location = System::Drawing::Point(633, 104);
			this->MR->Name = L"MR";
			this->MR->Size = System::Drawing::Size(85, 95);
			this->MR->TabIndex = 36;
			this->MR->Text = L"MR";
			this->MR->UseVisualStyleBackColor = true;
			this->MR->Click += gcnew System::EventHandler(this, &Form1::MR_Click);
			// 
			// MC
			// 
			this->MC->Dock = System::Windows::Forms::DockStyle::Fill;
			this->MC->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->MC->Location = System::Drawing::Point(633, 3);
			this->MC->Name = L"MC";
			this->MC->Size = System::Drawing::Size(85, 95);
			this->MC->TabIndex = 35;
			this->MC->Text = L"MC";
			this->MC->UseVisualStyleBackColor = true;
			this->MC->Click += gcnew System::EventHandler(this, &Form1::MC_Click);
			// 
			// deg
			// 
			this->deg->Dock = System::Windows::Forms::DockStyle::Fill;
			this->deg->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->deg->Location = System::Drawing::Point(543, 407);
			this->deg->Name = L"deg";
			this->deg->Size = System::Drawing::Size(84, 98);
			this->deg->TabIndex = 34;
			this->deg->Text = L"deg";
			this->deg->UseVisualStyleBackColor = true;
			this->deg->Click += gcnew System::EventHandler(this, &Form1::deg_Click);
			// 
			// cos
			// 
			this->cos->Dock = System::Windows::Forms::DockStyle::Fill;
			this->cos->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->cos->Location = System::Drawing::Point(543, 306);
			this->cos->Name = L"cos";
			this->cos->Size = System::Drawing::Size(84, 95);
			this->cos->TabIndex = 33;
			this->cos->Text = L"cos";
			this->cos->UseVisualStyleBackColor = true;
			this->cos->Click += gcnew System::EventHandler(this, &Form1::cos_Click);
			// 
			// sin
			// 
			this->sin->Dock = System::Windows::Forms::DockStyle::Fill;
			this->sin->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->sin->Location = System::Drawing::Point(543, 205);
			this->sin->Name = L"sin";
			this->sin->Size = System::Drawing::Size(84, 95);
			this->sin->TabIndex = 32;
			this->sin->Text = L"sin";
			this->sin->UseVisualStyleBackColor = true;
			this->sin->Click += gcnew System::EventHandler(this, &Form1::sin_Click);
			// 
			// tg
			// 
			this->tg->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tg->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->tg->Location = System::Drawing::Point(543, 104);
			this->tg->Name = L"tg";
			this->tg->Size = System::Drawing::Size(84, 95);
			this->tg->TabIndex = 31;
			this->tg->Text = L"tg";
			this->tg->UseVisualStyleBackColor = true;
			this->tg->Click += gcnew System::EventHandler(this, &Form1::tg_Click);
			// 
			// cotg
			// 
			this->cotg->Dock = System::Windows::Forms::DockStyle::Fill;
			this->cotg->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->cotg->Location = System::Drawing::Point(543, 3);
			this->cotg->Name = L"cotg";
			this->cotg->Size = System::Drawing::Size(84, 95);
			this->cotg->TabIndex = 30;
			this->cotg->Text = L"cotg";
			this->cotg->UseVisualStyleBackColor = true;
			this->cotg->Click += gcnew System::EventHandler(this, &Form1::cotg_Click);
			// 
			// ln
			// 
			this->ln->Dock = System::Windows::Forms::DockStyle::Fill;
			this->ln->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->ln->Location = System::Drawing::Point(453, 407);
			this->ln->Name = L"ln";
			this->ln->Size = System::Drawing::Size(84, 98);
			this->ln->TabIndex = 29;
			this->ln->Text = L"ln";
			this->ln->UseVisualStyleBackColor = true;
			this->ln->Click += gcnew System::EventHandler(this, &Form1::ln_Click);
			// 
			// random
			// 
			this->random->Dock = System::Windows::Forms::DockStyle::Fill;
			this->random->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->random->Location = System::Drawing::Point(453, 306);
			this->random->Name = L"random";
			this->random->Size = System::Drawing::Size(84, 95);
			this->random->TabIndex = 28;
			this->random->Text = L"rnd";
			this->random->UseVisualStyleBackColor = true;
			this->random->Click += gcnew System::EventHandler(this, &Form1::random_Click);
			// 
			// abs
			// 
			this->abs->Dock = System::Windows::Forms::DockStyle::Fill;
			this->abs->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->abs->Location = System::Drawing::Point(453, 205);
			this->abs->Name = L"abs";
			this->abs->Size = System::Drawing::Size(84, 95);
			this->abs->TabIndex = 27;
			this->abs->Text = L"|x|";
			this->abs->UseVisualStyleBackColor = true;
			this->abs->Click += gcnew System::EventHandler(this, &Form1::abs_Click);
			// 
			// faktorial
			// 
			this->faktorial->Dock = System::Windows::Forms::DockStyle::Fill;
			this->faktorial->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->faktorial->Location = System::Drawing::Point(453, 104);
			this->faktorial->Name = L"faktorial";
			this->faktorial->Size = System::Drawing::Size(84, 95);
			this->faktorial->TabIndex = 26;
			this->faktorial->Text = L"n!";
			this->faktorial->UseVisualStyleBackColor = true;
			this->faktorial->Click += gcnew System::EventHandler(this, &Form1::faktorial_Click);
			// 
			// prev
			// 
			this->prev->Dock = System::Windows::Forms::DockStyle::Fill;
			this->prev->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->prev->Location = System::Drawing::Point(453, 3);
			this->prev->Name = L"prev";
			this->prev->Size = System::Drawing::Size(84, 95);
			this->prev->TabIndex = 25;
			this->prev->Text = L"1/x";
			this->prev->UseVisualStyleBackColor = true;
			this->prev->Click += gcnew System::EventHandler(this, &Form1::prev_Click);
			// 
			// plus
			// 
			this->plus->Dock = System::Windows::Forms::DockStyle::Fill;
			this->plus->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->plus->Location = System::Drawing::Point(363, 407);
			this->plus->Name = L"plus";
			this->plus->Size = System::Drawing::Size(84, 98);
			this->plus->TabIndex = 24;
			this->plus->Text = L"+";
			this->plus->UseVisualStyleBackColor = true;
			this->plus->Click += gcnew System::EventHandler(this, &Form1::plus_Click);
			// 
			// minus
			// 
			this->minus->Dock = System::Windows::Forms::DockStyle::Fill;
			this->minus->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->minus->Location = System::Drawing::Point(363, 306);
			this->minus->Name = L"minus";
			this->minus->Size = System::Drawing::Size(84, 95);
			this->minus->TabIndex = 23;
			this->minus->Text = L"-";
			this->minus->UseVisualStyleBackColor = true;
			this->minus->Click += gcnew System::EventHandler(this, &Form1::minus_Click);
			// 
			// krat
			// 
			this->krat->Dock = System::Windows::Forms::DockStyle::Fill;
			this->krat->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->krat->Location = System::Drawing::Point(363, 205);
			this->krat->Name = L"krat";
			this->krat->Size = System::Drawing::Size(84, 95);
			this->krat->TabIndex = 22;
			this->krat->Text = L"X";
			this->krat->UseVisualStyleBackColor = true;
			this->krat->Click += gcnew System::EventHandler(this, &Form1::krat_Click);
			// 
			// deleno
			// 
			this->deleno->Dock = System::Windows::Forms::DockStyle::Fill;
			this->deleno->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->deleno->Location = System::Drawing::Point(363, 104);
			this->deleno->Name = L"deleno";
			this->deleno->Size = System::Drawing::Size(84, 95);
			this->deleno->TabIndex = 21;
			this->deleno->Text = L"/";
			this->deleno->UseVisualStyleBackColor = true;
			this->deleno->Click += gcnew System::EventHandler(this, &Form1::deleno_Click);
			// 
			// button6
			// 
			this->button6->Dock = System::Windows::Forms::DockStyle::Fill;
			this->button6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button6->Location = System::Drawing::Point(363, 3);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(84, 95);
			this->button6->TabIndex = 20;
			this->button6->Text = L"=";
			this->button6->UseVisualStyleBackColor = true;
			// 
			// eq
			// 
			this->eq->Dock = System::Windows::Forms::DockStyle::Fill;
			this->eq->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->eq->Location = System::Drawing::Point(273, 407);
			this->eq->Name = L"eq";
			this->eq->Size = System::Drawing::Size(84, 98);
			this->eq->TabIndex = 19;
			this->eq->Text = L"=";
			this->eq->UseVisualStyleBackColor = true;
			this->eq->Click += gcnew System::EventHandler(this, &Form1::eq_Click);
			// 
			// num0
			// 
			this->num0->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num0->Location = System::Drawing::Point(183, 407);
			this->num0->Name = L"num0";
			this->num0->Size = System::Drawing::Size(84, 98);
			this->num0->TabIndex = 18;
			this->num0->Text = L"0";
			this->num0->UseVisualStyleBackColor = true;
			this->num0->Click += gcnew System::EventHandler(this, &Form1::button19_Click);
			// 
			// comma
			// 
			this->comma->Dock = System::Windows::Forms::DockStyle::Fill;
			this->comma->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->comma->Location = System::Drawing::Point(93, 407);
			this->comma->Name = L"comma";
			this->comma->Size = System::Drawing::Size(84, 98);
			this->comma->TabIndex = 17;
			this->comma->Text = L",";
			this->comma->UseVisualStyleBackColor = true;
			this->comma->Click += gcnew System::EventHandler(this, &Form1::button18_Click);
			// 
			// opposite
			// 
			this->opposite->Dock = System::Windows::Forms::DockStyle::Fill;
			this->opposite->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->opposite->Location = System::Drawing::Point(3, 407);
			this->opposite->Name = L"opposite";
			this->opposite->Size = System::Drawing::Size(84, 98);
			this->opposite->TabIndex = 16;
			this->opposite->Text = L"+/-";
			this->opposite->UseVisualStyleBackColor = true;
			this->opposite->Click += gcnew System::EventHandler(this, &Form1::opposite_Click);
			// 
			// num3
			// 
			this->num3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num3->Location = System::Drawing::Point(273, 306);
			this->num3->Name = L"num3";
			this->num3->Size = System::Drawing::Size(84, 95);
			this->num3->TabIndex = 15;
			this->num3->Text = L"3";
			this->num3->UseVisualStyleBackColor = true;
			this->num3->Click += gcnew System::EventHandler(this, &Form1::num3_Click);
			// 
			// num2
			// 
			this->num2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num2->Location = System::Drawing::Point(183, 306);
			this->num2->Name = L"num2";
			this->num2->Size = System::Drawing::Size(84, 95);
			this->num2->TabIndex = 14;
			this->num2->Text = L"2";
			this->num2->UseVisualStyleBackColor = true;
			this->num2->Click += gcnew System::EventHandler(this, &Form1::num2_Click);
			// 
			// num1
			// 
			this->num1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num1->Location = System::Drawing::Point(93, 306);
			this->num1->Name = L"num1";
			this->num1->Size = System::Drawing::Size(84, 95);
			this->num1->TabIndex = 13;
			this->num1->Text = L"1";
			this->num1->UseVisualStyleBackColor = true;
			this->num1->Click += gcnew System::EventHandler(this, &Form1::num1_Click);
			// 
			// naDruhou
			// 
			this->naDruhou->Dock = System::Windows::Forms::DockStyle::Fill;
			this->naDruhou->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->naDruhou->Location = System::Drawing::Point(3, 306);
			this->naDruhou->Name = L"naDruhou";
			this->naDruhou->Size = System::Drawing::Size(84, 95);
			this->naDruhou->TabIndex = 12;
			this->naDruhou->Text = L"x^2";
			this->naDruhou->UseVisualStyleBackColor = true;
			this->naDruhou->Click += gcnew System::EventHandler(this, &Form1::naDruhou_Click);
			// 
			// num6
			// 
			this->num6->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num6->Location = System::Drawing::Point(273, 205);
			this->num6->Name = L"num6";
			this->num6->Size = System::Drawing::Size(84, 95);
			this->num6->TabIndex = 11;
			this->num6->Text = L"6";
			this->num6->UseVisualStyleBackColor = true;
			this->num6->Click += gcnew System::EventHandler(this, &Form1::num6_Click);
			// 
			// num5
			// 
			this->num5->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num5->Location = System::Drawing::Point(183, 205);
			this->num5->Name = L"num5";
			this->num5->Size = System::Drawing::Size(84, 95);
			this->num5->TabIndex = 10;
			this->num5->Text = L"5";
			this->num5->UseVisualStyleBackColor = true;
			this->num5->Click += gcnew System::EventHandler(this, &Form1::num5_Click);
			// 
			// num4
			// 
			this->num4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num4->Location = System::Drawing::Point(93, 205);
			this->num4->Name = L"num4";
			this->num4->Size = System::Drawing::Size(84, 95);
			this->num4->TabIndex = 9;
			this->num4->Text = L"4";
			this->num4->UseVisualStyleBackColor = true;
			this->num4->Click += gcnew System::EventHandler(this, &Form1::num4_Click);
			// 
			// pow
			// 
			this->pow->Dock = System::Windows::Forms::DockStyle::Fill;
			this->pow->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->pow->Location = System::Drawing::Point(3, 205);
			this->pow->Name = L"pow";
			this->pow->Size = System::Drawing::Size(84, 95);
			this->pow->TabIndex = 8;
			this->pow->Text = L"x^y";
			this->pow->UseVisualStyleBackColor = true;
			this->pow->Click += gcnew System::EventHandler(this, &Form1::pow_Click);
			// 
			// num9
			// 
			this->num9->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num9->Location = System::Drawing::Point(273, 104);
			this->num9->Name = L"num9";
			this->num9->Size = System::Drawing::Size(84, 95);
			this->num9->TabIndex = 7;
			this->num9->Text = L"9";
			this->num9->UseVisualStyleBackColor = true;
			this->num9->Click += gcnew System::EventHandler(this, &Form1::num9_Click);
			// 
			// num8
			// 
			this->num8->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num8->Location = System::Drawing::Point(183, 104);
			this->num8->Name = L"num8";
			this->num8->Size = System::Drawing::Size(84, 95);
			this->num8->TabIndex = 6;
			this->num8->Text = L"8";
			this->num8->UseVisualStyleBackColor = true;
			this->num8->Click += gcnew System::EventHandler(this, &Form1::num8_Click);
			// 
			// num7
			// 
			this->num7->Dock = System::Windows::Forms::DockStyle::Fill;
			this->num7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->num7->Location = System::Drawing::Point(93, 104);
			this->num7->Name = L"num7";
			this->num7->Size = System::Drawing::Size(84, 95);
			this->num7->TabIndex = 5;
			this->num7->Text = L"7";
			this->num7->UseVisualStyleBackColor = true;
			this->num7->Click += gcnew System::EventHandler(this, &Form1::num7_Click);
			// 
			// sqrt
			// 
			this->sqrt->Dock = System::Windows::Forms::DockStyle::Fill;
			this->sqrt->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->sqrt->Location = System::Drawing::Point(3, 104);
			this->sqrt->Name = L"sqrt";
			this->sqrt->Size = System::Drawing::Size(84, 95);
			this->sqrt->TabIndex = 4;
			this->sqrt->Text = L"sqrt(x)";
			this->sqrt->UseVisualStyleBackColor = true;
			this->sqrt->Click += gcnew System::EventHandler(this, &Form1::sqrt_Click);
			// 
			// del
			// 
			this->del->Dock = System::Windows::Forms::DockStyle::Fill;
			this->del->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->del->Location = System::Drawing::Point(273, 3);
			this->del->Name = L"del";
			this->del->Size = System::Drawing::Size(84, 95);
			this->del->TabIndex = 3;
			this->del->Text = L"<--";
			this->del->UseVisualStyleBackColor = true;
			this->del->Click += gcnew System::EventHandler(this, &Form1::del_Click);
			// 
			// Ce
			// 
			this->Ce->Dock = System::Windows::Forms::DockStyle::Fill;
			this->Ce->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->Ce->Location = System::Drawing::Point(183, 3);
			this->Ce->Name = L"Ce";
			this->Ce->Size = System::Drawing::Size(84, 95);
			this->Ce->TabIndex = 2;
			this->Ce->Text = L"Ce";
			this->Ce->UseVisualStyleBackColor = true;
			this->Ce->Click += gcnew System::EventHandler(this, &Form1::Ce_Click);
			// 
			// root
			// 
			this->root->Dock = System::Windows::Forms::DockStyle::Fill;
			this->root->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->root->Location = System::Drawing::Point(93, 3);
			this->root->Name = L"root";
			this->root->Size = System::Drawing::Size(84, 95);
			this->root->TabIndex = 1;
			this->root->Text = L"root";
			this->root->UseVisualStyleBackColor = true;
			this->root->Click += gcnew System::EventHandler(this, &Form1::root_Click);
			// 
			// pi
			// 
			this->pi->Dock = System::Windows::Forms::DockStyle::Fill;
			this->pi->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->pi->Location = System::Drawing::Point(3, 3);
			this->pi->Name = L"pi";
			this->pi->Size = System::Drawing::Size(84, 95);
			this->pi->TabIndex = 0;
			this->pi->Text = L"PI";
			this->pi->UseVisualStyleBackColor = true;
			this->pi->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// lbldeg
			// 
			this->lbldeg->AutoSize = true;
			this->lbldeg->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->lbldeg->Location = System::Drawing::Point(8, 87);
			this->lbldeg->Name = L"lbldeg";
			this->lbldeg->Size = System::Drawing::Size(43, 24);
			this->lbldeg->TabIndex = 3;
			this->lbldeg->Text = L"deg";
			// 
			// memory
			// 
			this->memory->AutoSize = true;
			this->memory->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->memory->Location = System::Drawing::Point(713, 87);
			this->memory->Name = L"memory";
			this->memory->Size = System::Drawing::Size(20, 24);
			this->memory->TabIndex = 4;
			this->memory->Text = L"0";
			// 
			// lblmemory
			// 
			this->lblmemory->AutoSize = true;
			this->lblmemory->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->lblmemory->Location = System::Drawing::Point(520, 87);
			this->lblmemory->Name = L"lblmemory";
			this->lblmemory->Size = System::Drawing::Size(79, 24);
			this->lblmemory->TabIndex = 5;
			this->lblmemory->Text = L"Memory";
			// 
			// Form1
			// 
			this->AcceptButton = this->abs;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::SkyBlue;
			this->ClientSize = System::Drawing::Size(787, 678);
			this->Controls->Add(this->lblmemory);
			this->Controls->Add(this->memory);
			this->Controls->Add(this->lbldeg);
			this->Controls->Add(this->tableLayoutPanel1);
			this->Controls->Add(this->disp);
			this->Controls->Add(this->pdisp);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->tableLayoutPanel1->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		

	



private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("pi");
}

	   //tlacitka s cisly
private: System::Void num1_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("1");
}
private: System::Void num2_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("2");
}
private: System::Void button19_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("0");
}
private: System::Void num3_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("3");
}
private: System::Void num4_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("4");
}
private: System::Void num5_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("5");
}
private: System::Void num6_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("6");
}
private: System::Void num7_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("7");
}
private: System::Void num8_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("8");
}
private: System::Void num9_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum("9");
}

private: void nextNum(String^ num) {
	if (num == ",") {
		if (disp->Text->Contains(","))return;
	}
	if (disp->Text == "0")disp->Text = "";
	disp->Text += num;
}

	private: void withOne(String^ operand) {
		if (operand == "^2") {
			double num1 = Convert::ToDouble(disp->Text);
			num1 = num1*num1;
			disp->Text = Convert::ToString(num1);
		}
		if (operand == "pi") {
			double pi = Math::PI;
			disp->Text = Convert::ToString(pi);
		}
		if (operand == "sq") {
			double num1 = Convert::ToDouble(disp->Text);
			double result = Math::Sqrt(num1);
			disp->Text = Convert::ToString(result);
		}
		if (operand == "1/x") {
			double num1 = Convert::ToDouble(disp->Text);
			double result = 1/num1;
			disp->Text = Convert::ToString(result);
		}
		if (operand == "fakt") {
			long long result = 1;
			double num1 = Convert::ToDouble(disp->Text);
			int num2 = (int)num1;
			if (num1 == num2) {
				
				for (num2;num2 > 0;num2--) {
					result *= num2;
				}
				disp->Text = Convert::ToString(result);
			}
			
		}
		if (operand == "abs") {
			double num1 = Convert::ToDouble(disp->Text);
			if (num1 < 0)num1 *= -1;
			disp->Text = Convert::ToString(num1);
		}
		if (operand == "rnd") {
			double num1;
			srand((time(NULL)));
			double r1 = static_cast<double>(rand());
			disp->Text = Convert::ToString(((round(r1 *10000) / 10000)));
		}
		if (operand == "ln") {
			double num1 = Convert::ToDouble(disp->Text);
			double result = Math::Log(num1);
			disp->Text = Convert::ToString(result);
		}
		if (operand == "sin" || operand == "cos" || operand == "cotg" || operand == "tg") {
			double num1 = Convert::ToDouble(disp->Text);
			double result;
			if (lbldeg->Text == "deg")num1 *= Math::PI / 180;
			if (operand == "tg")result = Math::Tan(num1);
			if (operand == "cotg")result = 1 / Math::Tan(num1);
			if (operand == "cos")result = Math::Cos(num1);
			if (operand == "sin")result = Math::Sin(num1);
			if (lbldeg->Text == "deg")num1 *= 180/Math::PI;
			disp->Text = Convert::ToString(result);
		}
		if (operand == "MS") {
			calulatePow();
			memory->Text = disp->Text;
		}
		if (operand == "MC") {
			memory->Text = "0";
		}
		if (operand == "MR") {
			disp->Text = memory->Text;
		}
		if (operand == "Mplus") {
			double num1 = Convert::ToDouble(memory->Text);
			double num2 = Convert::ToDouble(disp->Text);
			double result = num1 + num2;
			memory->Text = Convert::ToString(result);
		}
		if (operand == "Mminus") {
			double num1 = Convert::ToDouble(memory->Text);
			double num2 = Convert::ToDouble(disp->Text);
			double result = num1 - num2;
			memory->Text = Convert::ToString(result);
		}
	}
private: void operandy(String^ operand) {
	calulatePow();
	if (operand == "+" || operand=="-" || operand == "*" || operand == "/") {
		if (pdisp->Text != "") {
			equal();
		}

		if (pdisp->Text == "") {
			pdisp->Text = disp->Text;
			disp->Text = "";
			pdisp->Text += operand;
		}
	}
	if (operand == "=") {
		equal();
	}
}
	private: void calulatePow() {
		if (disp->Text->Contains("^")) {
			int pos = disp->Text->IndexOf("^");
			int lenght = disp->Text->Length;
			double num1 = Convert::ToDouble(disp->Text->Substring(0, pos));
			double num2 = Convert::ToDouble(disp->Text->Substring(pos + 1));
			double result = Math::Pow(num1, num2);
			disp->Text = Convert::ToString(result);
		}
		if (disp->Text->Contains("rt")) {
			int pos = disp->Text->IndexOf("rt");
			int lenght = disp->Text->Length;
			double num1 = Convert::ToDouble(disp->Text->Substring(0, pos));
			double num2 = Convert::ToDouble(disp->Text->Substring(pos + 2));
			double result = Math::Pow(num2, 1/num1);
			disp->Text = Convert::ToString(result);
		}
	}
private: void equal() {
	calulatePow();
	if ((disp->Text != "") && (pdisp->Text != "")) {
		char znam = ' ';
		if (pdisp->Text->EndsWith("+")) znam = '+';
		else if (pdisp->Text->EndsWith("-")) znam = '-';
		else if (pdisp->Text->EndsWith("/")) znam = '/';
		else if (pdisp->Text->EndsWith("*")) znam = '*';

	

		pdisp->Text = pdisp->Text->Substring(0, pdisp->Text->Length - 1);

		double num1, num2;
		try
		{
			num1 = Convert::ToDouble(disp->Text);
			num2 = Convert::ToDouble(pdisp->Text);
		}
		catch (Exception^ ex)
		{
			disp->Text = "Error pri prevodu na cislo";
			pdisp->Text = "";
			return;
		}

		disp->Text = "0";
		pdisp->Text = "";

		double result = 0.0;

		switch (znam) {
		case '+':
			result = num2 + num1;
			break;
		case '-':
			result = num2 - num1;
			break;
		case '*':
			result = num2 * num1;
			break;
		case '/':
			if (num1 == 0) {
				disp->Text = "Nulou se nedeli";
				return;
			}
			result = num2 / num1;
			break;
		default:
			disp->Text = "Error";
			return;
		}
		disp->Text = Convert::ToString(result);
	}
}

private: System::Void plus_Click(System::Object^ sender, System::EventArgs^ e) {
	operandy("+");
}

private: System::Void minus_Click(System::Object^ sender, System::EventArgs^ e) {
	operandy("-");
}
private: System::Void krat_Click(System::Object^ sender, System::EventArgs^ e) {
	operandy("*");
}
private: System::Void deleno_Click(System::Object^ sender, System::EventArgs^ e) {
	operandy("/");
}

private: System::Void eq_Click(System::Object^ sender, System::EventArgs^ e) {
	operandy("=");
}
private: System::Void del_Click(System::Object^ sender, System::EventArgs^ e) {
	int delka = disp->Text->Length;
	if (delka > 0)disp->Text=disp->Text->Remove(delka - 1);
	if (disp->Text == "-")disp->Text = "0";
}
private: System::Void Ce_Click(System::Object^ sender, System::EventArgs^ e) {
	disp->Text = "0";
	pdisp->Text = "";
}
private: System::Void button18_Click(System::Object^ sender, System::EventArgs^ e) {
	nextNum(",");

}
private: System::Void opposite_Click(System::Object^ sender, System::EventArgs^ e) {
	if (disp->Text != "0" && disp->Text->Length>0) {
		double num1 = Convert::ToDouble(disp->Text);
		num1 *= -1;
		disp->Text = Convert::ToString(num1);
	}


}
private: System::Void naDruhou_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("^2");
}

private: System::Void pow_Click(System::Object^ sender, System::EventArgs^ e) {
	if (!disp->Text->Contains("^"))disp->Text += ("^");

}
private: System::Void sqrt_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("sq");
}
private: System::Void root_Click(System::Object^ sender, System::EventArgs^ e) {
	if (!disp->Text->Contains("rt"))disp->Text += ("rt");
}
private: System::Void prev_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("1/x");
}
private: System::Void faktorial_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("fakt");
}
private: System::Void abs_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("abs");
}
private: System::Void random_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("rnd");
}
private: System::Void ln_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("ln");
}
private: System::Void cotg_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("cotg");
}
private: System::Void tg_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("tg");
}
private: System::Void sin_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("sin");
}
private: System::Void cos_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("cos");
}
private: System::Void deg_Click(System::Object^ sender, System::EventArgs^ e) {
	if (lbldeg->Text == "deg") {
		deg->Text = "rad";
		lbldeg->Text = "rad";
	}else{
		deg->Text = "deg";
		lbldeg->Text = "deg";
	}
}
private: System::Void MC_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("MC");
}
private: System::Void MR_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("MR");
}
private: System::Void Mplus_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("Mplus");
}
private: System::Void Mminus_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("Mminus");
}
private: System::Void MS_Click(System::Object^ sender, System::EventArgs^ e) {
	withOne("MS");
}
};



}
