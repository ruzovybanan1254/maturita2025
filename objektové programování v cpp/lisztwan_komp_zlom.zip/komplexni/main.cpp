#include "komplexni.h"
#include "Mat.h"
#include "zlomky.h"

void vypisMenu() {
	cout << "\n==== MENU ====" << endl;
	cout << "1 Zadat komplexni cisla" << endl;
	cout << "2 Vypocitat soucet" << endl;
	cout << "3 Vypocitat rozdil" << endl;
	cout << "4 Vypocitat nasobeni" << endl;
	cout << "5 Vypocitat deleni" << endl;
	cout << "6 Zobrazit absolutni hodnotu" << endl;
	cout << "7 Komplexne sdruzene cislo" << endl;
	cout << "8 Prevracene cislo" << endl;
	cout << "9 Vypis A a B" << endl;
	cout << "10 Ukoncit program" << endl;
	cout << "================\n" << endl;
	cout << "Vyberte akci ";
}

int main1() {
	Komplex a, b, vysledek;
	int volba;
	
	while (true) {
		vypisMenu();
		cin >> volba;
		
		switch (volba) {
		case 1:
			cout << "Zadejte prvni komplexni cislo a" << endl;
			cin >> a;
			cout << "Zadejte druhe komplexni cislo b" << endl;
			cin >> b;
			break;
			
		case 2:
			vysledek = a + b;
			cout << "Soucet a + b " <<endl;
			cout<< vysledek << endl;
			break;
			
		case 3:
			vysledek = a - b;
			cout << "Rozdil a - b "<<endl; 
			cout << vysledek << endl;
			break;
			
		case 4:
			vysledek = a * b;
			cout << "Nasobeni a * b " <<endl;
			cout<< vysledek << endl;
			break;
			
		case 5:
			vysledek = a / b;
			cout << "Deleni a / b " <<endl;
			cout<< vysledek << endl;
			break;
			
		case 6:
			vysledek=a;
			cout << "Absolutni hodnota a..... " << vysledek.absolutni() << endl;
			vysledek=b;
			cout << "Absolutni hodnota b..... " << vysledek.absolutni() << endl;
			break;
			
		case 7:
			cout << "Komplexne sdruzene cislo a ";
			vysledek=a;
			vysledek.koplexneSdruzene();
			cout << vysledek << endl;
			cout << "Komplexne sdruzene cislo b ";
			vysledek=b;
			vysledek.koplexneSdruzene();
			cout << vysledek << endl;
			break;
			
		case 8:
			cout << "Prevracene cislo a ";
			vysledek=a;
			vysledek.prevracene();
			cout << vysledek << endl;
			cout << "Prevracene cislo b ";
			vysledek=b;
			vysledek.prevracene();
			cout << vysledek << endl;
			break;
			
		case 9:
			cout <<a<<endl;
			cout <<b<<endl;
			break;
		case 10:
			cout << "Ukoncuji program Nashledanou" << endl;
			return 0;
			
		default:
			cout << "Neplatna volba zkuste to znovu" << endl;
			break;
		}
		system("pause");
		system("cls");
	}
	
	return 0;
}



using namespace std;

int main2() {
	Zlomek z1, z2, vysledek;
	int volba, moc;
	
	do {
		fflush(stdin);
		cout << "\n*** Kalkulacka se zlomky ***\n";
		cout << "1. Nacteni prvniho zlomku\n";
		cout << "2. Nacteni druheho zlomku\n";
		cout << "3. Vypis prvniho zlomku\n";
		cout << "4. Vypis druheho zlomku\n";
		cout << "5. Scitani zlomku\n";
		cout << "6. Odcitani zlomku\n";
		cout << "7. Nasobeni zlomku\n";
		cout << "8. Deleni zlomku\n";
		cout << "9. Umocnovani zlomku\n";
		cout << "10. Porovnani zlomku\n";
		cout << "11. Ukoncit program\n";
		cout << "Vyberte moznost: ";
		cin >> volba;
		
		switch (volba) {
		case 1:
			cout << "Zadejte prvni zlomek:\n";
			cin >> z1;
			break;
		case 2:
			cout << "Zadejte druhy zlomek:\n";
			cin >> z2;
			break;
		case 3:
			cout << "Prvni zlomek: " << z1;
			break;
		case 4:
			cout << "Druhy zlomek: " << z2;
			break;
		case 5:
			vysledek = z1 + z2;
			cout << "Vysledek scitani: " << vysledek;
			break;
		case 6:
			vysledek = z1 - z2;
			cout << "Vysledek odcitani: " << vysledek;
			break;
		case 7:
			vysledek = z1 * z2;
			cout << "Vysledek nasobeni: " << vysledek;
			break;
		case 8:
			vysledek = z1 / z2;
			cout << "Vysledek deleni: " << vysledek;
			break;
		case 9:
			cout << "Zadejte mocninu: ";
			cin >> moc;
			vysledek = z1.power(z1, moc);
			cout << "Vysledek umocnovani: " << vysledek;
			break;
		case 10:
			if (z1.compare(z1, z2) == 1)
				cout << "Prvni zlomek je vetsi\n";
			else if (z1.compare(z1, z2) == 2)
				cout << "Druhy zlomek je vetsi\n";
			else
				cout << "Zlomky jsou stejne\n";
			break;
		case 11:
			cout << "Konec programu\n";
			break;
		default:
			cout << "Neplatna volba, zkuste znovu\n";
		}
	system("pause");
		system("cls");
	} while (volba != 11);
	
	return 0;
}




int main3() {
	int choice;
	Matice m1(3), m2(3), result;
	
	
	do {
		cout << "Maticova kalkulacka"<<endl;
		cout << "########################"<<endl;
		cout << "#  1. Nacteni matic    #"<<endl;
		cout << "#  2. Vypis matic      #"<<endl;
		cout << "#  3. Soucet matic     #"<<endl;
		cout << "#  4. Rozdil matic     #"<<endl;
		cout << "#  5. Soucin matic     #"<<endl;
		cout << "#  6. Inverzni matice  #"<<endl;
		cout << "#  7. Konec            #"<<endl;
		cout << "########################"<<endl;
		cout << "Zadejte moznost: ";
		cin >> choice;
		switch(choice) {
		case 1:
			cout << "Zadejte prvni matici o velikosti 3x3:\n";
			cin >> m1;
			cout << "Zadejte druhou matici o velikosti 3x3:\n";
			cin >> m2;
			break;
		case 2:
			cout << "Prvni matice:\n" << m1;
			cout << "Druha matice:\n" << m2;
			break;
		case 3:
			result = m1 + m2;
			cout << "Soucet matic:\n" << result;
			break;
		case 4:
			result = m1 - m2;
			cout << "Rozdil matic:\n" << result;
			break;
		case 5:
			result = m1 * m2;
			cout << "Soucin matic:\n" << result;
			break;
		case 6:
			result = m1.inverzni();
			cout << "Inverzni matice:\n" << result;
			break;
		case 7:
			cout << "Konec programu.\n";
			break;
		default:
			cout << "Neplatna volba zkuste to znovu.\n";
		}
		system("pause");
		system("cls");
	} while(choice != 7);
	
	return 0;
}
int main(){
	int choice;
	Matice m1(3), m2(3), result;
	
	
	do {
		fflush(stdin);
		cout << "Maticova kalkulacka"<<endl;
		cout << "####################"<<endl;
		cout << "#  1. Komplexni    #"<<endl;
		cout << "#  2. Zlomky       #"<<endl;
		cout << "#  3. Matice       #"<<endl;
		cout << "#  4. Konec        #"<<endl;
		cout << "####################"<<endl;
		cout << "Zadejte moznost: ";
		cin >> choice;
		switch(choice) {
		case 1:
			main1();
			break;
		case 2:
			main2();
			break;
		case 3:
			main3();
			break;
		case 4:
			cout << "Konec programu.\n";
			break;
		default:
			cout << "Neplatna volba zkuste to znovu.\n";
		}
		system("pause");
		system("cls");
	} while(choice != 4);
	
	return 0;	
}
