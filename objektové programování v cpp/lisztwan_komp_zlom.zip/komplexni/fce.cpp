#include "komplexni.h"

Komplex::Komplex(){
	r=0;
	i=0;
}
Komplex::Komplex(double r, double i) {
	this->r=r;
	this->i=i;
}
ostream& operator<<(ostream& out,const Komplex& o){
	if(o.i<0){
		out<<o.r<<" "<< o.i<<"i"<<endl;
	}else{
		out<<o.r<<" + "<< o.i<<"i"<<endl;
	}
	return out;
}
istream& operator>>(istream& in, Komplex& o){
	cout<<"Zadejte realnou cast"<<endl;
	in>>o.r;
	cout<<"Zadejte imaginarni cast cast"<<endl;
	in>>o.i;
	return in;
}
Komplex Komplex::operator+(Komplex y){
	Komplex x;
	x.r =this->r + y.r;
	x.i =this->i + y.i;
	return x;
}
Komplex Komplex::operator-(Komplex y){
	Komplex x;
	x.r =this->r - y.r;
	x.i =this->i - y.i;
	return x;
}
Komplex Komplex::operator*(Komplex y){
	Komplex x;
	x.r = this->r * y.r - this->i * y.i;
	x.i = this->r * y.i + this->i * y.r;
	return x;
}
Komplex Komplex::operator/(Komplex y) {
	Komplex result= Komplex();
	double denominator = pow(y.r, 2) + pow(y.i, 2); 
	
	if (denominator == 0) {
		//throw runtime_error("Dělení nulou není povoleno.");
		return result;
	}
	
	result.r = (this->r * y.r + this->i * y.i) / denominator;
	result.i = (this->i * y.r - this->r * y.i) / denominator;
	
	return result;
}
double Komplex::absolutni(){
	return sqrt(pow(this->r, 2) + pow(this->i, 2));
}
void Komplex::prevracene(){
	Komplex novy;
	double delitel=pow(this->r, 2)+pow(this->i, 2);
	novy.r=this->r/delitel;
	novy.i=this->i/delitel;
	this->r=novy.r;
	this->i=novy.i;
}
