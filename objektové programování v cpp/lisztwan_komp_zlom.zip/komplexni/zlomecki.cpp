#include "zlomky.h"

void Zlomek::zkrat(){
	for(int i=2;i<1000;i++){
		if(((this->ci%i)==0)&&((this->jm%i)==0)){
			this->ci=this->ci/i;
			this->jm=this->jm/i;
			i=1;
		}
	}
}
void Zlomek::prevr(){
	Zlomek n;
	n.jm=this->ci;
	n.ci=this->jm;	
	this->ci=n.ci;
	this->jm=n.jm;
}

ostream& operator<<(ostream& out, const Zlomek& o){
	cout<<o.ci<<"/"<<o.jm<<"  "<<endl;
	return out;
}

istream& operator>>(istream& in, Zlomek& o){
	cout<<"Zadejte citatel a pak jmenovatel"<<endl;
	cin>>o.ci;
	cout<<"/";
	cin>>o.jm;
	return in;
}

Zlomek Zlomek::operator+(Zlomek y){
	int spol = this->jm*y.jm;
	Zlomek n;
	n.jm=spol;
	n.ci=((spol/this->jm)*this->ci)+((spol/y.jm)*y.ci);
	n.zkrat();
	return n;
}


Zlomek Zlomek::operator-(Zlomek y){
	int spol = this->jm*y.jm;
	Zlomek n;
	n.jm=spol;
	n.ci=((spol/this->jm)*this->ci)-((spol/y.jm)*y.ci);
	n.zkrat();
	return n;
}


Zlomek Zlomek::operator*(Zlomek y){
	Zlomek n;
	n.ci=this->ci*y.ci;
	n.jm=this->jm*y.jm;
	n.zkrat();
	return n;
}


Zlomek Zlomek::operator/(Zlomek y){
	y.prevr();
	Zlomek n;
	Zlomek pom;
	pom.ci=this->ci;
	pom.jm=this->jm;
	n=pom*y;
	n.zkrat();
	return n;
}

Zlomek Zlomek::power(Zlomek x, int moc){
	x.ci=pow(x.ci, moc);
	x.jm=pow(x.jm, moc);
	x.zkrat();
	return x;
}

int Zlomek::compare(Zlomek zlomek1, Zlomek zlomek2){
	double prvni=((double)zlomek1.ci)/((double)zlomek1.jm);
	double druhe=((double)zlomek2.ci)/(double)zlomek2.jm;
	if(prvni>druhe)return 1;
	if(prvni<druhe)return 2;
	return 0;
}
