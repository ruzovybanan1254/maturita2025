#include "mat.h"

std::ostream& operator<<(std::ostream& out, const Matice& m){
	
	cout<<"Matice["<<m.vel<<"]["<<m.vel<<"]"<<endl;
	for(int i=0;i<m.vel;i++){
		cout<<"|";
		for(int j=0;j<m.vel;j++){
			cout<<" "<<m.mati[i][j];
		}
		cout<<"|"<<endl;
	}
	return out;
}
std::istream& operator>>(std::istream& in, Matice& m){
	
	cout<<"Zadejte matici["<<m.vel<<"]["<<m.vel<<"]"<<endl;
	for(int i=0;i<m.vel;i++){
		cout<<"Zadejte radek "<<i+1<<": "<<endl;
		for(int j=0;j<m.vel;j++){
			cin>>m.mati[i][j];
		}
		system("cls");
	}
	return in;
}
Matice Matice::operator+(Matice y){
	if(this->vel!=y.vel){
		Matice z=Matice();
		cout<<"Jina velikost matic"<<endl;
		cout<<"nepokousej dobrotu programatora"<<endl;
		system("pause");
		system("cls");
		return z;
	}
	Matice pom=Matice(this->vel);
	for(int i=0;i<this->vel;i++){
		for(int j=0;j<this->vel;j++){
			pom.mati[i][j]=this->mati[i][j]+y.mati[i][j];
		}
	}
	return pom;
}
Matice Matice::operator-(Matice y){
	if(this->vel!=y.vel){
		Matice z=Matice();
		cout<<"Jina velikost matic"<<endl;
		cout<<"nepokousej dobrotu programatora"<<endl;
		system("pause");
		system("cls");
		return z;
	}
	Matice pom=Matice(this->vel);
	for(int i=0;i<this->vel;i++){
		for(int j=0;j<this->vel;j++){
			pom.mati[i][j]=this->mati[i][j]-y.mati[i][j];
		}
	}
	return pom;
}
Matice Matice::operator*(Matice y){
	if ((this->vel != y.vel)&&(this->vel<4)) {
		Matice z = Matice();
		cout << "Matice musi byt sejne velke a mensi nez 3" << endl;
		system("pause");
		system("cls");
		return z;
	}
	
	Matice result = Matice(this->vel);
	
	for (int i = 0; i < this->vel; i++) {
		for (int j = 0; j < this->vel; j++) {
			result.mati[i][j] = 0;
			for (int k = 0; k < this->vel; k++) {
				result.mati[i][j] += this->mati[i][k] * y.mati[k][j];
			}
		}
	}
	
	return result;
}

Matice Matice::inverzni() {//gener
	if (this->vel < 1) {
		cout<< "Matice je prilis mala na vypocet inverzni matice." <<endl;
		return Matice();
	}
	
	Matice result(this->vel); // Jednotkova matice
	Matice temp(*this);       // Kopie matice pro upravy
	
	// Inicializace jednotkove matice
	for (int i = 0; i < this->vel; i++) {
		for (int j = 0; j < this->vel; j++) {
			result.mati[i][j] = (i == j) ? 1 : 0;
		}
	}
	

	for (int i = 0; i < this->vel; i++) {
		// Kontrola, zda diagonální prvek není nulový
		if (temp.mati[i][i] == 0) {
			cout<< "nieidzie" <<endl;
			return Matice();
		}
		
		// Normalizace diagonálního prvku
		double diag = temp.mati[i][i];
		for (int j = 0; j < this->vel; j++) {
			temp.mati[i][j] /= diag;
			result.mati[i][j] /= diag;
		}
		
		// Eliminace ostatních řádků
		for (int k = 0; k < this->vel; k++) {
			if (k != i) {
				double factor = temp.mati[k][i];
				for (int j = 0; j < this->vel; j++) {
					temp.mati[k][j] -= factor * temp.mati[i][j];
					result.mati[k][j] -= factor * result.mati[i][j];
				}
			}
		}
	}
	
	
	return result;
}

