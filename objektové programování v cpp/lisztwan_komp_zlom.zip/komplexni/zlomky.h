#ifndef ZLOMKY_H
#define ZLOMKY_H
#include <sstream>
#include <iostream>
#include <cmath>

using namespace std;
class Zlomek {
private:
	int ci;
	int jm;
	void zkrat();
public:
	Zlomek() {
		this->ci=1;
		this->jm=1;
	}
	Zlomek(int citatel, int jmenovatel) {
		this->ci=citatel;
		this->jm=jmenovatel;
	}
	void prevr();
	void setCi(int citatel){
		this->ci=citatel;
	}
	void setJm(int jmenovatel){
		if(jmenovatel!=0){
			this->jm=jmenovatel;
		}
	}
	Zlomek power(Zlomek x, int moc);
	int compare(Zlomek zlomek1, Zlomek zlomek2);
	int getCi(){
		return this->ci;
	}
	int getJm(){
		return this->jm;
	}
	friend ostream& operator<<(ostream& out, const Zlomek& o);
	friend istream& operator>>(istream& in, Zlomek& o);
	
	
	Zlomek operator+(Zlomek y);
	Zlomek operator-(Zlomek y);
	Zlomek operator*(Zlomek y);
	Zlomek operator/(Zlomek y);
};
#endif
