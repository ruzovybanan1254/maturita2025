#ifndef MAT_H
#define MAT_H
#define MAX 8
#include <iostream>
#include <sstream>
using namespace std;
class Matice {
private:
	int vel;
	int mati[MAX][MAX];
public:
	Matice() {
		vel=3;
	}
	Matice(int velikost) {
		vel=velikost;
	}
	Matice(int velikost, int pole[MAX][MAX]) {
		vel=velikost;
		for(int i=0;i<this->vel;i++){
			for(int j=0;j<this->vel;j++){
				this->mati[i][j]=pole[i][j];
			}
		}
	}
	friend std::ostream& operator<<(std::ostream& out, const Matice& m);
	friend std::istream& operator>>(std::istream& in, Matice& m);
	Matice operator+(Matice y);
	Matice operator-(Matice y);
	Matice operator*(Matice y);
	Matice inverzni();
	
};

#endif
