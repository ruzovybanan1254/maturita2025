#ifndef KOMPLEXNI_H
#define KOMPLEXNI_H
#include <sstream>
#include <iostream>
#include <cmath>

using namespace std;
class Komplex {
private: 
	double r;
	double i;
public:
	Komplex();
	Komplex(double r, double i);
	friend ostream& operator<<(ostream& out, const Komplex& o);
	friend istream& operator>>(istream& in, Komplex& o);
	void koplexneSdruzene() {
		this->i=-1*this->i;
	}
	Komplex operator+(Komplex y);
	Komplex operator-(Komplex y);
	Komplex operator*(Komplex y);
	Komplex operator/(Komplex y);
	double absolutni();
	void prevracene();
};

#endif


